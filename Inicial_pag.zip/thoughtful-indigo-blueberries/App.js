import React from 'react';
import { View, Text, StyleSheet, Image,} from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      <View style={styles.circle4}>
        <View style={styles.circle3}>
          <View style={styles.circle2}>
            <View style={styles.circle}>
            <Image source={require('./assets/logoPDM.png')} style={styles.imagem} />
          </View>
        </View>
      </View>
    </View>
      <Text style={styles.mainText}>Durar HR</Text>
      <Text style={styles.subText}>The Complete HR Solutions</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 9,
    backgroundColor: '#e20030', 
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 50, 
  },
  circle: {
    width: 100,
    height: 100,
    backgroundColor: '#FFFFFF',
    borderRadius: 50,
    marginBottom: 20,
    alignItems: 'center',
    overflow: 'hidden',
    justifyContent: 'center',
    paddingBottom: 6,
   
  },
  mainText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'left',
    position: 'absolute',
    bottom: 30, 
  },
  subText: {
    color: '#FFFFFF',
    fontSize: 16,
    position: 'absolute',
    bottom: 10, 
  },
  imagem: {
    height: 80,
    width: 80,
  },
  circle2: {
    width: 150,
    height: 150,
    backgroundColor: '#e94668',
    borderRadius: 1000,
    marginBottom: 20,
    alignItems: 'center',
    overflow: 'hidden',
    justifyContent: 'flex-end',
    paddingBottom: 6,
 
  },
  circle3: {
    width: 200,
    height: 200,
    backgroundColor: '#e63359',
    borderRadius: 1000,
    marginBottom: 20,
    alignItems: 'center',
    overflow: 'hidden',
    justifyContent: 'flex-end',
    verticalAlign:  'center',
    paddingBottom: 6,

  },
  circle4: {
    width: 250,
    height: 250,
    backgroundColor: '#ea1948',
    borderRadius: 250,
    marginBottom: 20,
    alignItems: 'center',
    overflow: 'hidden',
    justifyContent: 'flex-end',
    paddingBottom: 6,

  },
});

export default App;




